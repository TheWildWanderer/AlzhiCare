package com.example.alzhicare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import java.util.Calendar;

public class RemindersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminders);

    }
    public void appointmentMethod(View v){
        final boolean[] isPlaying = {false};
        ImageButton pills = (ImageButton)findViewById(R.id.buttonAppointment);
        pills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                Intent intent = new Intent(Intent.ACTION_EDIT);
                intent.setType("vnd.android.cursor.item/event");
                intent.putExtra("title", "You have an appointment with ____");
                startActivity(intent);
            }
        });
    }

    public void pillsMethod(View v){
        final boolean[] isPlaying = {false};
        ImageButton pills = (ImageButton)findViewById(R.id.buttonPills);
        pills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                Intent intent = new Intent(Intent.ACTION_EDIT);
                intent.setType("vnd.android.cursor.item/event");
                intent.putExtra("beginTime", cal.getTimeInMillis());
                intent.putExtra("allDay", true);
                intent.putExtra("rrule", "FREQ=DAILY");
                intent.putExtra("endTime", cal.getTimeInMillis()+60*60*1000);
                intent.putExtra("title", "Take Razadyne");
                startActivity(intent);
            }
        });
    }

    public void waterMethod(View v){
        final boolean[] isPlaying = {false};
        ImageButton pills = (ImageButton)findViewById(R.id.buttonWater);
        pills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                Intent intent = new Intent(Intent.ACTION_EDIT);
                intent.setType("vnd.android.cursor.item/event");
                intent.putExtra("beginTime", cal.getTimeInMillis());
                intent.putExtra("allDay", true);
                intent.putExtra("rrule", "FREQ=DAILY");
                intent.putExtra("endTime", cal.getTimeInMillis()+60*60*1000);
                intent.putExtra("title", "Get some water");
                startActivity(intent);
            }
        });
    }

    public void mealMethod(View v){
        final boolean[] isPlaying = {false};
        ImageButton pills = (ImageButton)findViewById(R.id.buttonMeals);
        pills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                Intent intent = new Intent(Intent.ACTION_EDIT);
                intent.setType("vnd.android.cursor.item/event");
                intent.putExtra("rrule", "FREQ=DAILY");
                intent.putExtra("title", "Meal Time!");
                startActivity(intent);
            }
        });
    }

}