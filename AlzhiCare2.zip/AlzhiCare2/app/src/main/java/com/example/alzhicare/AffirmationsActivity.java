package com.example.alzhicare;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class AffirmationsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affirmations);

        final ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("I am fearfully and wonderfully made.", R.raw.voice1));
        words.add(new Word("I contribute to this world everyday.", R.raw.voice2));
        words.add(new Word("I find happiness and comfort in making through it each day.", R.raw.voice3));
        words.add(new Word("I will conquer every single day that dawns upon me.", R.raw.voice4));
        words.add(new Word("I am blessed with a family that gives me hope, purpose and joy.", R.raw.voice5));
        words.add(new Word("I have the benifit of wisdom and experience.", R.raw.voice6));
        words.add(new Word("I am surrounded by people who love and care for me.", R.raw.voice7));
        words.add(new Word("This is my time to relax, count my blessings and cherish the people who matter to me.", R.raw.voice8));
        words.add(new Word("I am living the best years of my life.", R.raw.voice9));
        words.add(new Word("I am proud to have lived for so long.", R.raw.voice10));

        // Create an {@link WordAdapter}, whose data source is a list of {@link Word}s. The
        // adapter knows how to create list items for each item in the list.
        WordAdapter adapter = new WordAdapter(this, words);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.
        ListView listView = (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        listView.setAdapter(adapter);

        // Set a click listener to play the audio when the list item is clicked on
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                // Get the {@link Word} object at the given position the user clicked on
                Word word = words.get(position);

                Toast.makeText(AffirmationsActivity.this,"Affirm After the Audio is Played",Toast.LENGTH_SHORT).show();

                MediaPlayer mMediaPlayer = MediaPlayer.create(AffirmationsActivity.this, word.getAudioResourceId());
                mMediaPlayer.start();
            }
        });

    }
}