package com.example.alzhicare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity<MaterialButton> extends AppCompatActivity {

    EditText polnumber,textname,textemail;
    Button set_button;

    public static final String SHARED_PREFS="sharedPrefs";
    public static final String CALL="call";
    public static final String TEXT="text";
    public static final String EMAIL="email";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        polnumber=findViewById(R.id.polnumber);
        textname=findViewById(R.id.textname);
        textemail=findViewById(R.id.textemail);
        set_button=findViewById(R.id.set_button);

        loadUpData();

        set_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                saveData();
                Toast.makeText(getBaseContext(),"Details Set", Toast.LENGTH_SHORT).show();
                loadData();
            }
        });


    }

    public void loadUpData(){

        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        polnumber.setText(sharedPreferences.getString(CALL,""));
        textname.setText(sharedPreferences.getString(TEXT,""));
        textemail.setText(sharedPreferences.getString(EMAIL,""));


    }

    public void saveData(){

        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();

        editor.putString(CALL,polnumber.getText().toString());
        editor.putString(TEXT,textname.getText().toString());
        editor.putString(EMAIL,textemail.getText().toString());
        editor.commit();

    }
    public void loadData() {

        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        String callNumber=sharedPreferences.getString(CALL,"");
        String textNumber=sharedPreferences.getString(TEXT,"");
        String textemail = sharedPreferences.getString(EMAIL,"");

    }

}